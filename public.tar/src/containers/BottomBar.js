import React, {Component} from 'react';
import Footer from 'grommet/components/Footer'
const BottomBar = () => (
    <Footer>
        <p>Footer</p>
        <p>Add address and contacts</p>
    </Footer>
)

export default BottomBar;