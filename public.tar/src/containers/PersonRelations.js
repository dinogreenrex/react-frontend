import React, {Component} from 'react';

class Relations extends React.Component {
    constructor(props){
        super(props)
    }
    render(){
        return (
            <div>
                <h2>Person relations with other persons</h2>
            </div>
        )
    }
}

export default Relations;