import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import {isloginformactive} from './loginformactive';
import {loginstate} from './ReducerAction';
import { connect } from 'react-redux'

class Form extends React.Component {
    constructor(props,context){
        super(props);
    }
    render() {
        return (
                <div className="login-form">
                    <form onSubmit={this.handleSubmit}>
                        <div className="username">
                            <label>Username</label>
                            <input type="text" name='username' ref={node => {
                                this.username = node
                            }} onChange={ this.handleChange}/>
                        </div>
                        <div className="password">
                            <label>Password</label>
                            <input type="text" name="password" ref={node => {
                                this.password = node
                            }} onChange={this.handleChange}/>
                        </div>
                        <input type="submit" value="login"/>

                    </form>
                </div>
        )
    }

}

/*
 viewport
   -> topbar
    -> LoginLink (if !isUserLogged}
    -> LoginForm {if loginformActive}
    -> {userName} {if isUserLogged}
    -> logout (if isUserLogged }
   -> content
    -> PersonListContainer (redux)
       -> ListToolbar
         -> add -> redirects to /person/add
         -> edit -> redirects to /person/edit/<id>
         -> delete -> thunk action
       -> PersonList
          -> ...N records






 */

class LoginForm extends React.Component {
    constructor(props){
        super(props);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.ShowHideForm = this.ShowHideForm.bind(this);
    }


    componentDidMount(){

    }
    componentWillMount(){

    }
    componentWillUnmount(){

    }

    ShowHideForm(){
        // action creators

        this.props.dispatch({
            type: 'LOGINFORM_TOGGLE'
        });
        console.log(this);
    }

    handleSubmit(event){
        event.preventDefault();

        this.username.value='';
        this.password.value='';

        console.log(event);
    }
    handleChange(){

    }
    
    
    render(){
        return (
            <div className="mainpage-user">
                <div >
                    <a href="#" onClick={this.ShowHideForm}>Login</a>
                </div>
                <div >
                    {this.props.formactive ? <div className="mainpage-form-user"><Form /></div> : null }
                </div>
            </div>
        )
    }
}
/* state => {
 return {
 isActive: isloginformactive(state.isActive)
 }
 }
 mapStateToProps(),
 dispatch => {
 return {
 onTodoClick: test => {
 dispatch(isloginformactive(test))
 }
 }
 },*/
const returnFormActive = (formactive) => {
    return formactive
}

export default connect(
    (state,props) => {
        return {
            formactive: state.freducer.formactive
        }
    }
)(LoginForm)